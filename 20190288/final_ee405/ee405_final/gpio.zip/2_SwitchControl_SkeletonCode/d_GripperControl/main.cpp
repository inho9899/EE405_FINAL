#include <iostream>

int main(int, char**){
    std::cout << "Hello, from gripper_control!\n";
}
